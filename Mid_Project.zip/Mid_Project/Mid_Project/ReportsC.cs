﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text.pdf.draw;
using System.ComponentModel.Design.Serialization;
using CRUD_Operations;

namespace Mid_Project
{
    public partial class ReportsC : UserControl
    {
        string name;
        string line;
        DataTable dt;
        public ReportsC()
        {
            InitializeComponent();
            //PopulateDateComboBox();
            comboBox2.Items.Clear();
            comboBox2.Items.Add("Assessment wise Result of Student");
            comboBox2.Items.Add("Clo Wise Result of Students(who attempts Assessments)");
            comboBox2.Items.Add("Clo Wise Marks in Assessment Components of Students");
        }
        /*
        private void PopulateDateComboBox()
        {
            try
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("SELECT DISTINCT AttendanceDate FROM ClassAttendance", con2);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DateTime date = Convert.ToDateTime(reader["AttendanceDate"]);
                    comboBoxDates.Items.Add(date.ToString("yyyy-MM-dd"));
                }
                reader.Close();
                con2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while populating date combo box: " + ex.Message);
            }
        }

        private DataTable loadAttendanceReport(DateTime selectedDate)
        {
            DataTable dt = new DataTable();
            try
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand("SELECT sa.AttendanceId, s.FirstName + ' ' + s.LastName AS StudentName, sa.AttendanceStatus " +
                                                 "FROM StudentAttendance sa " +
                                                 "JOIN Student s ON sa.StudentId = s.Id " +
                                                 "WHERE sa.AttendanceDate = @Date", con2);
                cmd2.Parameters.AddWithValue("@Date", selectedDate);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading attendance data: " + ex.Message);
            }
            return dt;
        }
        */

        private DataTable load1()
        {
            DataTable dt = new DataTable();
            try
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand($" select \r\n  st.StudentId,s.FirstName as Name, s.RegistrationNumber as RegNo,Assessment.Title as Assessment,\r\n  st.AssessmentComponentId as ACID ,\r\n  ac.TotalMarks as Marks,\r\n  rl.MeasurementLevel,\r\n  max(rl2.MeasurementLevel)  as MaxLevel ,\r\n  Cast (CAST(rl.MeasurementLevel AS FLOAT) / max( CAST(rl2.MeasurementLevel AS FLOAT) )* ac.TotalMarks as float) as OMarks \r\n\r\n  from StudentResult as st \r\n  join Student as s \r\n  on st.StudentId=s.Id \r\n  join AssessmentComponent as ac \r\n  on ac.Id=st.AssessmentComponentId \r\n  join Rubric as r\r\n  on r.Id=ac.RubricId \r\n  join RubricLevel as rl \r\n  on rl.Id=st.RubricMeasurementId \r\n  join RubricLevel as rl2 \r\n  on rl2.RubricId=r.Id \r\n  join Assessment \r\n  on Assessment.Id=ac.AssessmentId \r\n  group by st.StudentId,st.AssessmentComponentId,ac.TotalMarks,rl.MeasurementLevel,s.FirstName,s.RegistrationNumber,Assessment.Title", con2);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading data for load1: " + ex.Message);
            }
            return dt;
        }
        private DataTable load2()
        {
            DataTable dt = new DataTable();
            try
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand($"SELECT S.RegistrationNumber,  SUM(AC.TotalMarks)AS TotalMarks,Cast(SUM(((RL.MeasurementLevel / (RL.Maximum * 1.0)) * AC.TotalMarks))as int) AS ObtainedMarks\r\nFROM Student S\r\n JOIN StudentResult SR ON S.Id = SR.StudentId\r\n JOIN AssessmentComponent AC ON AC.Id = SR.AssessmentComponentId\r\n JOIN Assessment A ON A.Id = AC.AssessmentId\r\n JOIN Rubric R ON R.Id = AC.RubricId\r\n JOIN Clo C ON C.Id = R.CloId\r\n JOIN (SELECT Id, RubricId, MeasurementLevel, R.Maximum FROM RubricLevel, \r\n           (SELECT RubricId AS RID, MAX(RubricLevel.MeasurementLevel) AS Maximum \r\n            FROM RubricLevel GROUP BY RubricId) AS R \r\n           WHERE RubricLevel.RubricId = R.RID) AS RL\r\nON SR.RubricMeasurementId = RL.ID\r\nGROUP BY S.RegistrationNumber\r\n", con2);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading data for load1: " + ex.Message);
            }
            return dt;
        }
        private DataTable load3()
        {
            DataTable dt = new DataTable();
            try
            {
                var con2 = Configuration.getInstance().getConnection();
                SqlCommand cmd2 = new SqlCommand($"    select \r\nConcat(s.FirstName,s.LastName) as StudentName, s.RegistrationNumber,Clo.Name,Assessment.Title,\r\nac.name as AComponent,\r\n  ac.TotalMarks as totalmarks,\r\n\r\n  Cast (CAST(rl.MeasurementLevel AS FLOAT)/ max( CAST(rl2.MeasurementLevel AS FLOAT) )* ac.TotalMarks as float) as Obtainedarks\r\n\r\n  from StudentResult as st\r\n  join Student as s\r\n  on st.StudentId=s.Id\r\n  join AssessmentComponent as ac\r\n  on ac.Id=st.AssessmentComponentId\r\n  join Rubric as r\r\n  on r.Id=ac.RubricId\r\n  join RubricLevel as rl\r\n  on rl.Id=st.RubricMeasurementId\r\n  join RubricLevel as rl2\r\n  on rl2.RubricId=r.Id\r\n  join Assessment\r\n  on Assessment.Id=ac.AssessmentId\r\n  join Clo\r\n  on r.CloId=Clo.Id\r\n\r\n  group by st.AssessmentComponentId,ac.TotalMarks,rl.MeasurementLevel,Concat(s.FirstName,s.LastName),s.RegistrationNumber,Clo.Name,ac.Name,Assessment.Title\r\n", con2);
                SqlDataAdapter da = new SqlDataAdapter(cmd2);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading data for load1: " + ex.Message);
            }
            return dt;
        }

        private void ExportToPDF(DataTable dt, string name, string description)
        {
            try
            {
                using (Document document = new Document(PageSize.A4, 20, 20, 20, 20))
                {
                    PdfWriter.GetInstance(document, new FileStream(name + ".pdf", FileMode.Create));
                    document.Open();

                    // Add report name and description to the PDF
                    Paragraph reportNameParagraph = new Paragraph(name, new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 18, iTextSharp.text.Font.BOLD));
                    reportNameParagraph.Alignment = Element.ALIGN_CENTER;
                    document.Add(reportNameParagraph);

                    Paragraph reportDescriptionParagraph = new Paragraph(description, FontFactory.GetFont("Times New Roman", 12));
                    reportDescriptionParagraph.Alignment = Element.ALIGN_CENTER;
                    document.Add(reportDescriptionParagraph);

                    // Add table with data from DataTable
                    PdfPTable table = new PdfPTable(dt.Columns.Count);
                    table.WidthPercentage = 100;

                    // Add column headers
                    foreach (DataColumn column in dt.Columns)
                    {
                        table.AddCell(new PdfPCell(new Phrase(column.ColumnName)));
                    }

                    // Add data rows
                    foreach (DataRow row in dt.Rows)
                    {
                        foreach (object item in row.ItemArray)
                        {
                            table.AddCell(new PdfPCell(new Phrase(item.ToString())));
                        }
                    }

                    document.Add(table);
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("An error occurred while generating the report: " + exp.Message);
            }
        }


        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            
            if (comboBox2.Text == "Assessment wise Result of Student")
            {
                dt = load1();
            }
            else if (comboBox2.Text == "Clo Wise Result of Students(who attempts Assessments)")
            {
                dt = load2();
            }
            else if (comboBox2.Text == "Clo Wise Marks in Assessment Components of Students")
            {
                dt = load3();
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                string reportName = "";
                string reportDescription = "";

                if (comboBox2.Text == "Assessment wise Result of Student")
                {
                    reportName = "Report of Students per Assessment Wise";
                    reportDescription = "Shows the marks of each Assessment Components";
                }
                else if (comboBox2.Text == "Clo Wise Result of Students(who attempts Assessments)")
                {
                    reportName = "CLO Wise Result of Students";
                    reportDescription = "Report of CLO Wise result of Students Who attempts Assessment";
                }
                else if (comboBox2.Text == "Clo Wise Marks in Assessment Components of Students")
                {
                    reportName = "CLO Wise Result of Assessment Components";
                    reportDescription = "Report of CLO Wise result of Students According to the Assessment Components they have attempted yet";
                }

                ExportToPDF(dt, reportName, reportDescription);
                MessageBox.Show("Report Generated");
                //this.Hide();
            }
            else
            {
                MessageBox.Show("No data available for the selected report.");
                //this.Hide();
                //this.
            }
        }

        private void gbx_Enter(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Close_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedOption = comboBox2.SelectedItem.ToString();
            DataTable dt = null;

            if (selectedOption == "Assessment wise Result of Student")
            {
                dt = load1();
            }
            else if (selectedOption == "Clo Wise Result of Students(who attempts Assessments)")
            {
                dt = load2();
            }
            else if (selectedOption == "Clo Wise Marks in Assessment Components of Students")
            {
                dt = load3();
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                
                datagridView.DataSource = dt;
                datagridView.DefaultCellStyle.ForeColor = Color.Black;
            }
            else
            {
                
                datagridView.DataSource = null;
                MessageBox.Show("No data available for the selected report.");
            }
        }
    }
}
